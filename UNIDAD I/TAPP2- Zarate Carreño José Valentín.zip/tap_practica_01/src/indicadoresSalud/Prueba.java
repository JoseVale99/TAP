
package indicadoresSalud;

public class Prueba {

    public static void main(String[] args) {

        IndicadoresSalud e = new IndicadoresSalud();

    }

}
