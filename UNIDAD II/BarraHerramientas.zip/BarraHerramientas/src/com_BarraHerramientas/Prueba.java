/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com_BarraHerramientas;

import componentes.MiBoton;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author josed
 */
public class Prueba extends JFrame implements ActionListener{
    BarraHerramientas b;
    MiBoton [] arreglo= {new MiBoton("Boton 1"), new MiBoton("Boton 2")};
    MiBoton b1= new MiBoton("Boton 3");
    MiBoton b2= new MiBoton("Boton 4");
    public Prueba(){
        b= new BarraHerramientas();
      /*  b= new BarraHerramientas(arreglo);
        b.agregarBoton(b1);
        b.agregarBoton(b2);
        for(int i=0;i<b.getBotones().length;i++)
            System.out.println(b.getBotones()[i].getText());
                
        setSize(500,500);*/
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        b.getBotones()[0].setIcono(new ImageIcon("src/salvar.png"), 20, 20);
        b.getBotones()[2].setImagenTexto("Hola",new ImageIcon("src/salvar.png"), 20, 20); 
        b.getBotones()[1].setText("HOLA");
        b.getBotones()[1].agregarEvento(this);
        b.getBotones()[3].setBackground(new Color(93,193,185));
        add(b);
        pack();
    }
    public void actionPerformed(ActionEvent e){
        System.out.println("HOLA");
        JOptionPane.showMessageDialog(null, "HOLA MUNDO");
    }

    public static void main(String[] args) {
        new Prueba();
    }
}
