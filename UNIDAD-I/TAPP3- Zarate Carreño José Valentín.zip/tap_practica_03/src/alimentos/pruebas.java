package alimentos;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.UIManager;
public class pruebas {
    public static void main(String[] args) {   
    try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ManejoAlimentos.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(ManejoAlimentos.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(ManejoAlimentos.class.getName()).log(Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            Logger.getLogger(ManejoAlimentos.class.getName()).log(Level.SEVERE, null, ex);
        }
       ManejoAlimentos alimentos = new ManejoAlimentos();
        alimentos.setSize(680, 390);
        alimentos.setVisible(true);
    
    }
}

