
package ModeloControlador;

import ModeloVista.Vista;
import ModeloVotacion.Modelo;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;
import javax.swing.JButton;
import javax.swing.JTextField;


public class Controlador implements ActionListener{
   int inc=0;
    int i1=0,i2=0,i3=0;
    private final Vista v;
    private final Modelo modelo;
 
   

    public Controlador(Vista v,Modelo modelo) {
         this.v=v;
    this.modelo=modelo;
    }
 
  public void actionPerformed (ActionEvent ae){
        JButton boton=(JButton) ae.getSource();
        JButton btn1 = v.getVotar1();
        JButton btn2 = v.getVotar2();
        JButton btn3 = v.getVotar3();
        JButton rein = v.getReiniciar();

       
        
        JTextField p1 = v.getPressupuesto1();
        JTextField p2 = v.getPressupuesto2();
        JTextField p3 = v.getPressupuesto3();
        
                
                
        if(boton==btn1){
            inc++; i1++;
        v.Persona1(i1, i2, i3); 
        v.Persona2(inc);
        }else 
        if(boton==btn2){inc++; i2++;
        v.Persona1(i1, i2, i3);
        v.Persona2(inc);
        }else
        if(boton==btn3){
            inc++; i3++;
        v.Persona1(i1, i2, i3);
        v.Persona2(inc);
        }
        Double r1 = modelo.Operacion1(inc,i1);
        Double r2 = modelo.Operacion2(inc,i2);
        Double r3 = modelo.Operacion3(inc,i3);
        v.Persona3(inc, r1, r2, r3);
        if (boton==rein){
        inc=0;
         i1=0;
         i2=0;
         i3=0;
         r1=0.0;
         r2=0.0;
         r3=0.0;
         v.Reiniciar(i1, i2, i3,inc,r1,r2,r3);
        }
      
    }
}

       

        

    
    
    

